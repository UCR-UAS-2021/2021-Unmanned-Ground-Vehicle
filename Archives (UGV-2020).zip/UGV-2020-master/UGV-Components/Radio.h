#ifndef RADIO_H
#define RADIO_H

#include <RH_RF69.h>
#include <RHReliableDatagram.h>

void radioSetup();
void ping();

#endif